# Por ahora, este archivo está vacío. Se implementará más adelante.
def menu_evaluaciones(campus):
    print("Módulo de evaluaciones en desarrollo.")